import { $ } from '../../utils/dom.js';
import { BookingAPI } from '../../api/booking.js';

import {updateCost} from "./cost.js";
import {CalendarUI} from "../calendar/index.js";


export const BookingModal = {
  store: null,

  init(store) {
    this.store = store;
    $('#booking-form')?.addEventListener('submit', this.submit.bind(this));
    $('#close-modal')?.addEventListener('click', () => this.close());
    $('#cancel-booking')?.addEventListener('click', () => this.close());
  },

  open({ date, time, tableId }) {
    this.slot = { date, time, tableId };
    this.populateForm();
    $('#booking-modal').classList.remove('hidden');
  },

  populateForm() {
    const { date, time, tableId } = this.slot;
    $('#booking-date').value = date;
    $('#booking-start-time').value = time;
    $('#booking-table').value = tableId;
    updateCost(this.store);
  },

  async submit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    payload.table_id = Number(payload.table_id);
    payload.duration = Number(payload.duration);
    payload.participants = Number(payload.participants);
    payload.equipment = []; // TODO собрать чекбоксы
    payload.date = this.slot.date;
    payload.start_time = this.slot.time;

    const { booking_id } = await BookingAPI.create(payload);
    await BookingAPI.payment(booking_id);
    this.close();
   await CalendarUI.render();
  },

  close() {
    $('#booking-modal').classList.add('hidden');
  }
};