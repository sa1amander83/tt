import { post } from './index.js';

export const PromoAPI = {
  validate: (code, userId) => post('/management/validate-promo/', { code, user_id: userId })
};